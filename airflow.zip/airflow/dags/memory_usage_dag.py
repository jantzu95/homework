from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago
import psutil
import smtplib
from email.mime.text import MIMEText
import os

def send_email(subject, body):
    sender_email = os.getenv('SMTP_MAIL_FROM')
    receiver_email = os.getenv('RECEIVER_EMAIL', 'receiver@example.com')
    password = os.getenv('SMTP_PASSWORD')
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = receiver_email

    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, msg.as_string())

def check_memory_usage():
    memory = psutil.virtual_memory().percent
    if memory > 80:
        send_email("Kõrge mälukasutus", f"Mälukasutus on {memory}%!")

dag = DAG(
    'memory_usage_check',
    default_args={'owner': 'airflow'},
    schedule_interval='@hourly',
    start_date=days_ago(1),
    catchup=False
)

check_memory = PythonOperator(
    task_id='check_memory_usage',
    python_callable=check_memory_usage,
    dag=dag
)
