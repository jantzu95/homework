from airflow import DAG
from airflow.operators.python import PythonOperator
import pendulum
import psutil
import smtplib
from email.mime.text import MIMEText
import logging
import time

# Parameetrid
MEMORY_THRESHOLD = 10  # Protsentides
EMAIL_TO = "lipjanar@gmail.com"  # Siia saadetakse e-post
EMAIL_FROM = "airflowdagtestkonto@gmail.com"
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = "airflowdagtestkonto@gmail.com"
SMTP_PASSWORD = "nohf pswr ezmg wija"  # Rakenduse parool

# Kontrollib süsteemi mälukasutust
def check_memory(ti):
    """Kontrollib süsteemi mälukasutust ja saadab teavituse, kui kasutus on üle piiri."""
    try:
        mem = psutil.virtual_memory()
        usage = mem.percent
        logging.info(f"📊 Hetke mälukasutus: {usage}%")

        if usage > MEMORY_THRESHOLD:
            logging.warning(f"⚠️ HOIATUS: Mälukasutus on liiga kõrge! ({usage}%)")
            ti.xcom_push(key='memory_usage', value=usage)
            send_alert_email(usage)

    except Exception as e:
        logging.error(f"❌ Mälukasutuse kontrollimise viga: {e}")

def send_alert_email(usage):
    """Saadab e-posti teavituse kõrge mälukasutuse korral."""
    if not SMTP_USER or not SMTP_PASSWORD:
        logging.error("❌ SMTP kasutajanimi või parool puudub! E-posti ei saadeta.")
        return

    subject = f"⚠️ High Memory Usage Alert: {usage}%"
    body = f"⚠️ HOIATUS! Süsteemi mälukasutus on {usage}%, mis ületab lubatud piiri {MEMORY_THRESHOLD}%."

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = EMAIL_FROM
    msg["To"] = EMAIL_TO

    for attempt in range(3):  # 3 katset enne vea andmist
        try:
            server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.sendmail(EMAIL_FROM, EMAIL_TO, msg.as_string())
            server.quit()
            logging.info("✅ E-posti teavitus saadetud edukalt!")
            return
        except Exception as e:
            logging.error(f"❌ E-posti saatmine ebaõnnestus (katse {attempt+1}/3): {e}")
            time.sleep(5)  # Oota 5 sekundit enne uut katset

# Airflow DAG konfiguratsioon
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': pendulum.today('UTC').add(days=-1),
    'retries': 1,
}

dag = DAG(
    'memory_usage_dag',
    default_args=default_args,
    schedule='*/5 * * * *',  # Jookseb iga 5 minuti tagant
    catchup=False,
)

task = PythonOperator(
    task_id='check_memory',
    python_callable=check_memory,
    dag=dag,
)

task
